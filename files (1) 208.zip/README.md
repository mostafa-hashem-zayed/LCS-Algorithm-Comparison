# LCS Project — CSCI208 Spring 2026

## How to Run

**Requirements:** Python 3 (no extra libraries needed)

```bash
# Main program — enter two strings interactively
python lcs.py

# Performance benchmark — tests across multiple lengths
python performance_test.py
```

---

## Team Task Division

| # | Member | Task |
|---|---|---|
| 1 | Member 1 | **Algorithm Implementation** — Write all three LCS functions in `lcs.py` with comments |
| 2 | Member 2 | **Performance Testing** — Write `performance_test.py`, collect and record results |
| 3 | Member 3 | **Report** — Write `report.md` with complexity analysis and explanation |
| 4 | Member 4 | **Presentation** — Build the slide deck, prepare visual examples |
| 5 | Member 5 | **Testing & Demo** — Test edge cases, prepare example inputs for the discussion |

---

## Expected Discussion Questions & Answers

**Q1: What is a subsequence? How is it different from a substring?**
A: A subsequence keeps characters in order but they don't have to be consecutive. A substring must be consecutive. Example: for "ABCDE", "ACE" is a subsequence but not a substring.

**Q2: Why does the recursive approach get so slow?**
A: Because it solves the same sub-problems many times. For example, LCS("ABC", "AC", 1, 1) might be called dozens of times in the same run. This causes exponential time: O(2^(n+m)).

**Q3: How does Dynamic Programming fix the recursive problem?**
A: By storing results in a table. Each cell dp[i][j] is computed only once. When we need it again, we just look it up instead of recomputing. This reduces time from exponential to O(n×m).

**Q4: Why is Brute Force even worse than Recursive?**
A: Brute Force generates ALL 2ⁿ subsequences in memory. It uses O(2ⁿ) space just to store them. Recursive at least only branches when needed (even if it repeats).

**Q5: Walk me through the DP table for s1="AB" and s2="AB".**
A:
```
     ε  A  B
  ε  0  0  0
  A  0  1  1
  B  0  1  2
```
- dp[1][1]: 'A'=='A' → 0+1 = 1
- dp[1][2]: 'A'!='B' → max(0,1) = 1
- dp[2][1]: 'B'!='A' → max(1,0) = 1
- dp[2][2]: 'B'=='B' → 1+1 = 2
- LCS = "AB", length = 2

**Q6: Can there be more than one LCS?**
A: Yes. For s1="ABCB" and s2="BCB", both "BCB" and "BCB" are valid (same here), but in other cases like s1="AXBY" s2="AYXB", both "AXB" and "AYB" are valid LCS of length 3.

**Q7: What is the time complexity of each algorithm?**
A:
- Brute Force: O(2ⁿ × m) time, O(2ⁿ) space
- Recursive: O(2^(n+m)) time, O(n+m) space (call stack)
- Dynamic Programming: O(n×m) time, O(n×m) space

**Q8: What are real-world uses of LCS?**
A: Git diff (comparing file versions), DNA sequence alignment in bioinformatics, spell checkers, and file comparison tools.

**Q9: Why did you skip Brute Force and Recursive for long strings in your program?**
A: For strings longer than ~18-20 characters, those algorithms take minutes or even hours. We added a length check to avoid the program hanging — and to demonstrate that we understand the complexity limits.

**Q10: Could you improve the space complexity of DP?**
A: Yes. Since each row only depends on the previous row, we can use just two rows (O(m) space) instead of the full table. But this makes it harder to reconstruct the actual LCS string, so for clarity we kept the full table.

---

## Edge Cases to Test

| Input | Expected |
|---|---|
| s1="", s2="ABC" | LCS = "" (empty) |
| s1="AAA", s2="AAA" | LCS = "AAA" |
| s1="ABC", s2="XYZ" | LCS = "" (no common chars) |
| s1="ABCBDAB", s2="BDCABA" | LCS = "BCBA" (classic example) |
| s1="A", s2="A" | LCS = "A" |

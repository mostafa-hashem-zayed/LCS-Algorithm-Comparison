# CSCI208 Project Report
## Longest Common Subsequence (LCS)
**Spring 2026**

---

## 1. Introduction

The Longest Common Subsequence (LCS) problem asks: given two strings, what is the longest sequence of characters that appears in both strings in the same relative order — but not necessarily consecutively?

**Example:**
- String 1: `ABCBDAB`
- String 2: `BDCABA`
- LCS: `BCBA` (length = 4)

LCS has real-world applications in:
- **Version control** (diff tools like `git diff`)
- **Bioinformatics** (DNA/RNA sequence alignment)
- **Spell checkers and autocomplete**

---

## 2. Problem Definition

Given two strings `s1` of length `n` and `s2` of length `m`, find the longest string `L` such that:
- Every character of `L` appears in `s1` in the same order.
- Every character of `L` appears in `s2` in the same order.
- `L` has maximum possible length.

---

## 3. Algorithms Implemented

### 3.1 Brute Force

**Idea:** Generate all possible subsequences of `s1`, then check which ones also appear in `s2`. Keep the longest match.

**Steps:**
1. Generate all 2ⁿ subsequences of `s1`.
2. For each subsequence, check if it is a subsequence of `s2`.
3. Track the longest one found.

**Time Complexity:** O(2ⁿ × m)
**Space Complexity:** O(2ⁿ)
**Why it's slow:** A string of length 20 has over 1 million subsequences. At length 30, that's over 1 billion.

---

### 3.2 Recursive

**Idea:** Compare characters from the end of both strings. If they match, count them and move inward. If not, try two options (skip from either string) and take the better result.

**Recurrence:**
```
LCS(s1, s2, i, j):
  if i == 0 or j == 0: return ""
  if s1[i-1] == s2[j-1]: return LCS(s1, s2, i-1, j-1) + s1[i-1]
  return max(LCS(s1, s2, i-1, j), LCS(s1, s2, i, j-1))
```

**Time Complexity:** O(2^(n+m)) — exponential due to overlapping sub-problems
**Space Complexity:** O(n+m) — recursion call stack depth
**Problem:** The same sub-problems are solved repeatedly. For example, `LCS("ABC", "AC", 2, 2)` might be called dozens of times.

---

### 3.3 Dynamic Programming

**Idea:** Build a 2D table `dp[i][j]` where each cell stores the LCS length for `s1[:i]` and `s2[:j]`. Fill the table once — no repeated work.

**Fill rule:**
```
if s1[i-1] == s2[j-1]:
    dp[i][j] = dp[i-1][j-1] + 1
else:
    dp[i][j] = max(dp[i-1][j], dp[i][j-1])
```

After filling, trace back through the table to reconstruct the actual LCS string.

**Time Complexity:** O(n × m) — fill each of the n×m cells exactly once
**Space Complexity:** O(n × m) — the table itself
**Why it's best:** Eliminates all redundant computation.

---

## 4. Performance Results

| String Length | Brute Force | Recursive | Dynamic Prog |
|:---:|---:|---:|---:|
| 5  | 0.03 ms | 0.01 ms | 0.02 ms |
| 8  | 0.24 ms | 0.18 ms | 0.02 ms |
| 10 | 0.72 ms | 1.54 ms | 0.03 ms |
| 12 | 3.02 ms | 4.64 ms | 0.04 ms |
| 15 | 32.26 ms | 633 ms | 0.05 ms |
| 18 | 314.67 ms | 7,771 ms | 0.09 ms |
| 20 | — (too slow) | 146,199 ms | 0.10 ms |

**Conclusion:** Dynamic Programming is hundreds of times faster and handles any input length.

---

## 5. Complexity Summary

| Algorithm | Time | Space | Practical Limit |
|---|---|---|---|
| Brute Force | O(2ⁿ × m) | O(2ⁿ) | ~18 characters |
| Recursive | O(2^(n+m)) | O(n+m) | ~20 characters |
| Dynamic Programming | O(n × m) | O(n × m) | Any length |

---

## 6. Project Files

| File | Purpose |
|---|---|
| `lcs.py` | Main program — all three algorithms + console interface |
| `performance_test.py` | Benchmark script — measures and prints timing table |
| `LCS_Presentation.pptx` | Slide deck for the discussion |
| `report.md` | This report |
| `README.md` | How to run the project |

---

## 7. How to Run

```bash
# Run the main program
python lcs.py

# Run performance benchmark
python performance_test.py
```

---

## 8. Team Contributions

| Member | Role |
|---|---|
| Member 1 | Algorithm implementation (all three LCS functions) |
| Member 2 | Performance testing and benchmark script |
| Member 3 | Report and documentation |
| Member 4 | Presentation slides |
| Member 5 | Testing, edge cases, demo preparation |

---

## 9. References

- Cormen, T. H., et al. *Introduction to Algorithms* (CLRS), 4th Ed. — Chapter 15: LCS
- Lecture notes, CSCI208 Spring 2026

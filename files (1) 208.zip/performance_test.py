"""
performance_test.py
Tests all three LCS algorithms across different string lengths
and prints a comparison table.
Run: python performance_test.py
"""

import time
import random
import string
from lcs import lcs_recursive, lcs_brute_force, lcs_dp


def random_string(length):
    """Generate a random lowercase string of given length."""
    return ''.join(random.choices("abcde", k=length))  # small alphabet → more matches


def measure(func, *args):
    """Return execution time in milliseconds."""
    start = time.time()
    func(*args)
    return (time.time() - start) * 1000


def run_tests():
    print("=" * 65)
    print("   LCS PERFORMANCE COMPARISON")
    print("=" * 65)
    print(f"{'Length':>8} | {'Brute Force (ms)':>18} | {'Recursive (ms)':>16} | {'DP (ms)':>10}")
    print("-" * 65)

    test_sizes = [5, 8, 10, 12, 15, 18, 20]

    for n in test_sizes:
        s1 = random_string(n)
        s2 = random_string(n)

        # DP — always run
        t_dp = measure(lcs_dp, s1, s2)

        # Recursive — skip if too long
        if n <= 20:
            t_rec = measure(lcs_recursive, s1, s2, n, n)
            rec_str = f"{t_rec:>16.2f}"
        else:
            rec_str = f"{'skip':>16}"

        # Brute Force — skip if too long
        if n <= 18:
            t_bf = measure(lcs_brute_force, s1, s2)
            bf_str = f"{t_bf:>18.2f}"
        else:
            bf_str = f"{'skip':>18}"

        print(f"{n:>8} | {bf_str} | {rec_str} | {t_dp:>10.2f}")

    print("=" * 65)
    print("\n  Conclusion:")
    print("  - Dynamic Programming is fastest for all sizes.")
    print("  - Recursive doubles in time with each extra character.")
    print("  - Brute Force becomes unusable past length ~18.")


if __name__ == "__main__":
    run_tests()

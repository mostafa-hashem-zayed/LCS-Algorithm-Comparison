import time

# Recursive LCS
def recursive_lcs(s1, s2, m, n, memo):
    if m == 0 or n == 0:
        return ""
    if (m, n) in memo:
        return memo[(m, n)]
    if s1[m - 1] == s2[n - 1]:
        result = recursive_lcs(s1, s2, m - 1, n - 1, memo) + s1[m - 1]
    else:
        a = recursive_lcs(s1, s2, m - 1, n, memo)
        b = recursive_lcs(s1, s2, m, n - 1, memo)
        result = a if len(a) > len(b) else b
    memo[(m, n)] = result
    return result

# Brute Force LCS
def get_subsequences(s):
    result = [""]
    for ch in s:
        result += [x + ch for x in result]
    return result

def is_subsequence(sub, s):
    i = 0
    for ch in s:
        if i < len(sub) and ch == sub[i]:
            i += 1
    return i == len(sub)

def brute_force_lcs(s1, s2):
    best = ""
    for sub in get_subsequences(s1):
        if is_subsequence(sub, s2) and len(sub) > len(best):
            best = sub
    return best

# Dynamic Programming LCS
def dp_lcs(s1, s2):
    m, n = len(s1), len(s2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if s1[i - 1] == s2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    lcs = ""
    i, j = m, n
    while i > 0 and j > 0:
        if s1[i - 1] == s2[j - 1]:
            lcs = s1[i - 1] + lcs
            i -= 1
            j -= 1
        elif dp[i - 1][j] > dp[i][j - 1]:
            i -= 1
        else:
            j -= 1
    return lcs

# Main Program
s1 = input("Enter first string: ")
s2 = input("Enter second string: ")

start = time.time()
r = recursive_lcs(s1, s2, len(s1), len(s2), {})
print("\nRecursive:")
print("LCS =", r, "| Length =", len(r))
print("Time =", round((time.time() - start) * 1000, 4), "ms")

start = time.time()
b = brute_force_lcs(s1, s2)
print("\nBrute Force:")
print("LCS =", b, "| Length =", len(b))
print("Time =", round((time.time() - start) * 1000, 4), "ms")

start = time.time()
d = dp_lcs(s1, s2)
print("\nDynamic Programming:")
print("LCS =", d, "| Length =", len(d))
print("Time =", round((time.time() - start) * 1000, 4), "ms")
